"""MQTT Bridge module"""
