# Core configuration and initialization
