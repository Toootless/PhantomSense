"""LLM Reasoning module"""
