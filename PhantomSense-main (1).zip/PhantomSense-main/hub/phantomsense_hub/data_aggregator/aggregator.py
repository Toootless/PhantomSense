"""Data aggregation module"""
